const { ActivityType } = require("discord.js")
const { joinVoiceChannel } = require('@discordjs/voice');



module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        const channel = client.channels.cache.get('1256957896240136222')
        await joinVoiceChannel({
            channelId: channel.id,
            guildId: channel.guild.id,
            adapterCreator: channel.guild.voiceAdapterCreator,
        });
        client.user.setPresence({
            activities: [{ name: 'Life Hogwarts Roleplay', type: ActivityType.Playing }],
            status: 'online', // online, idle, dnd, invisible
        });
        console.log(`${client.user.tag} şu anda aktif.`)
    }
}