const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'messageDelete',
    async execute(message, client) {
        const sahip = message.author;
        const kanal = client.channels.cache.get('1248722864329195593');

        if (!kanal || !sahip) return;

        const embed = new EmbedBuilder()
            .setTitle('**Bir mesaj silindi.**')
            .addFields(
                {
                    name: "Mesajın silindiği kanal:",
                    value: `<#${message.channel.id}>`,
                    inline: true,
                },
                {
                    name: "Mesajı silen kişi:",
                    value: sahip.tag,
                    inline: false,
                },
                {
                    name: "Mesajın içeriği:",
                    value: message.content || "Mesajın içeriği yok.",
                    inline: false,
                }
            )
            .setFooter({
                text: `Log sistemi - ${message.guild.name}`,
                iconURL: message.guild.iconURL({ dynamic: true }),
            })
            .setTimestamp();

        kanal.send({ embeds: [embed] });
    },
};
