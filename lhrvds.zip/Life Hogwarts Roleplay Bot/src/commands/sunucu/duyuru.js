const { EmbedBuilder } = require('discord.js')

module.exports = {
    name: "duyur",
    description: "Sunucu duyuru kanalına istediğiniz duyuruyu gönderir.",
    aliases: ["duyuru", "d",],
    async execute(client, message, args) {
        const author = message.author;
        const text = args.slice(0).join(" ");
        const kanal = client.channels.cache.get('1248723383630172294')
        const embed = new EmbedBuilder()
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setTitle("Duyuru <:pembis_11:1249393403418906707>")
            .setDescription(text)
            .setColor("#e1e1d5")
            .setFooter({
                text: `Duyuru sistemi - ${message.guild.name}`,
                iconURL: message.guild.iconURL({ dynamic: true })
            })
            .setTimestamp()
        kanal.send("@everyone")
        kanal.send({ embeds: [embed]})
    }
}