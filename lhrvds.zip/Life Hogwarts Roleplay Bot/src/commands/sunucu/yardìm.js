const { EmbedBuilder } = require("discord.js")

module.exports = {
    name: "yardım",
    description: "Bottaki tüm komutları gösterir",
    aliases: ["y", "help" , "yrdm" , "yardim" , "komutlar"],
    async execute(client, message, args) {
        const embed = new EmbedBuilder()
        .setTitle(message.guild.name + " Bot Bilgi")
        .addFields(
            {
                name: "Roleplay komutları:",
                value: `!rp, !rplist, !seyahat #kanal, /profil`,
                inline: true
            },
            {
                name: "Ekonomi komutları:",
                value: `!bakiye, !zenginler, !maaş , !paragönder , !satınal @eşya`,
                inline: true
            },
            {
                name: "Seviye komutları:",
                value: "!seviye, !seviyelist",
                inline: true
            },
            {
                name: "Duello komutu:",
                value: "!duello @kişi",
                inline: true
            },
            {
                name: "Eşyalar ve Statlar:",
                value: "!çanta, !stats",
                inline: true
            }
        )
        .setFooter(
            {
                text: "Life Hogwarts Bot - Bilgi",
                iconURL: message.guild.iconURL({dynamic: true})
            }
        )
        message.reply({ embeds: [embed] })
    }
}