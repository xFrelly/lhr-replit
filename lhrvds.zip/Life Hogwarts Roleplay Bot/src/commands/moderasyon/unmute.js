const fetchTime = require('../../functions/moderation/fetchTime');

module.exports = {
    name: "unmute",
    description: "Bahsedilen kişinin susturmasını kaldırır.",
    aliases: ["unsustur", "mutekaldır"],
    async execute(client, message, args) {
        if (!message.member.permissions.has('MANAGE_ROLES')) {
            return message.channel.send('Bu komutu kullanmak için yetkin yok.');
        }

        const member = message.mentions.members.first();
        if (!member) {
            return message.channel.send('Lütfen susturulması kaldırılacak kişiyi belirt.');
        }

        const muteRoleId = "1261054114738077716"; // Your mute role ID
        await member.roles.remove(muteRoleId);

        const storedTime = await fetchTime(member.id, message.guild.id);
        storedTime.muteUntil = null;
        await storedTime.save();

        member.send(`${message.guild.name} kanalında susturulmanız kaldırıldı.`);
        message.channel.send(`${member} kullanıcısının susturulması kaldırıldı.`);
    }
};
