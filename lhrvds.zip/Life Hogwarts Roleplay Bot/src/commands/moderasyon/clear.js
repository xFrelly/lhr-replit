const { PermissionsBitField } = require("discord.js");

module.exports = {
    name: "clear",
    description: "Kanaldaki mesajları temizler.",
    aliases : ["temizle", "purge", "süpür"],
    async execute(client,message,args) {
  let veri = args[0]
  if(!args[0]) return message.reply("Lütfen kaç mesaj silineceğini belirtiniz.");
  if(!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages) || !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return message.reply(`Bu komutu kullanmak için sunucu yetkili olmanız gerekir.`);

  message.channel.bulkDelete(veri , veri)
  message.channel.send(`${veri} adet mesajı sildim.`)
}
}
