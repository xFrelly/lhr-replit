const fetchTime = require('../../functions/moderation/fetchTime');

module.exports = {
    name: "mute",
    description: "Bahsedilen kişiyi susturur.",
    aliases: ["sustur", "mutela"],
    async execute(client, message, args) {
        if (!message.member.permissions.has('MANAGE_ROLES' || !message.member.permissions.has("ADMINISTRATOR"))) {
            return message.channel.send('Bu komutu kullanmak için yetkin yok.');
        }

        const member = message.mentions.members.first();
        if (!member) {
            return message.channel.send('Lütfen susturulacak kişiyi belirt.');
        }

        let gün = parseInt(args[1]);
        if (isNaN(gün) || gün <= 0) {
            return message.channel.send('Lütfen kaç gün susturulacağını belirt.');
        }

        const sebep = args.slice(2).join(" ");
        if (!sebep) {
            return message.channel.send('Lütfen susturulma için bir sebep belirt.');
        }

        let storedTime = await fetchTime(member.id, message.guild.id);
        let muteUntil = new Date();
        muteUntil.setDate(muteUntil.getDate() + gün);
        storedTime.muteUntil = muteUntil;

        await storedTime.save();

        const muteRoleId = "1261054114738077716"; // Your mute role ID
        member.roles.set([muteRoleId]);
        message.react('✅');

        member.send(`${message.guild.name} kanalından *${sebep}* sebebiyle **${gün}** gün süreyle susturuldunuz.`);
        message.author.send(`Susturduğunuz ${member} kullanıcısının eski rolleri: ${member.roles.cache.map(role => role.name).join(", ")}`);

        // Schedule unmute
        setTimeout(async () => {
            const updatedTime = await fetchTime(member.id, message.guild.id);
            if (new Date() >= updatedTime.muteUntil) {
                await member.roles.remove(muteRoleId);
                member.send(`${message.guild.name} kanalında susturulmanız sona erdi. Yetkililerimize ulaşınız.`);
                updatedTime.muteUntil = null;
                await updatedTime.save();
            }
        }, gün * 24 * 60 * 60 * 1000);
    }
};
