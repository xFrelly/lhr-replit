const { EmbedBuilder } = require("discord.js")
const chalk = require('chalk')
module.exports = {
    name: "kick",
    description: "Bahsedilen kullanıcıyı sunucudan atar.",
    aliases: ["at", "tükür" , "gönder"],
    async execute(client, message, args) {
        let gifler = ["https://i.pinimg.com/originals/67/6d/f6/676df67b445733237820a3b7d70db942.gif",
            "https://media.harrypotterfanzone.com/harry-uses-the-cruciatus-curse.gif"
        ]
        let randomgif = gifler[Math.floor(Math.random() * gifler.length)]
        let target = message.mentions.members.first()
        if (!message.member.permissions.has('KICK_MEMBERS')
            ||
            !message.member.permissions.has('ADMINISTRATOR')) {
            message.channel.send('Bu yetkiye sahip değilsin!')
        } else if (!target) {
            message.channel.send('Kimi sunucudan atacaksın?')
        } else {
            target.ban()
            let embed = new EmbedBuilder()
                .setDescription(`${target}' sunucudan başarıyla atıldı.`)
                .setFooter({
                    text: message.guild.name,
                    iconURL: message.guild.iconURL({ dynamic: true })
                })
                .setTimestamp()
            message.channel.send({ embeds: [embed]})
            message.channel.send(randomgif)
            console.log(chalk.magenta('Az önce `!kick` komutu çalıştırıldı!'))
        }
    }
}
