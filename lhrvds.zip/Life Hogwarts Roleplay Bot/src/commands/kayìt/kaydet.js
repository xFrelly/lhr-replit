const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: "kaydet",
    data: new SlashCommandBuilder()
        .setName('kaydet')
        .setDescription('Belirtilen rolleri bir kullanıcıya verir.')
        .addUserOption(option =>
            option.setName('kullanici')
                .setDescription('Rol verilecek kullaniciyi seçin.')
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('cinsiyet')
                .setDescription('Verilecek cinsiyet rolü [Büyücü - Cadi]')
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('bina')
                .setDescription('Verilecek bina rolü.')
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('kan')
                .setDescription('Verilecek kan grubu rol. - [Safkan-Melez-Bulanik]')
                .setRequired(true)),
    async execute(interaction, message) {
        if(message.content == "!kaydet") return;
        if(!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles) || !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator))
             interaction.reply(`Bu komutu kullanmak için gerekli izne sahip değilsiniz.`)
        const member = interaction.options.getMember('kullanici');
        const role1 = interaction.options.getRole('cinsiyet');
        const role2 = interaction.options.getRole('bina');
        const role3 = interaction.options.getRole('kan');
        const role4 = interaction.guild.roles.cache.get('1248745536584945757')

        try {
            await member.roles.remove(role4)
            await member.roles.add(role1);
            if (role2) await member.roles.add(role2);
            if (role3) await member.roles.add(role3);

            await interaction.reply({ content: `${member} kullanıcısına belirtilen roller verildi.`, ephemeral: true });
        } catch (error) {
            console.error('Error assigning roles:', error);
            await interaction.reply({ content: 'Roller atanırken bir hata oluştu.', ephemeral: true });
        }
    }
};
