module.exports = {
    name: "benikurtar",
    description: "Cem Gökmen olur da mal bir şey yaparsa bot onu kurtarır.",
    aliases: ["kurtar"],
    async execute(client, message, args){
        const role = message.guild.roles.cache.get('1248742264071651338')
        const role2 = message.guild.roles.cache.get('1248742341775458365')
        const role3 = message.guild.roles.cache.get('1250664252050771978')
        const role4 = message.guild.roles.cache.get('1248745536584945757')
        const member = message.guild.members.cache.get('356034188886933504')
        if(!member) return message.reply("Bu komutu sadece <@356034188886933504> kullanabilir.");
        member.roles.add(role)
        member.roles.add(role2)
        member.roles.add(role3)
        member.roles.remove(role4)
        member.send("Sizi kurtardım efendim!")

    }
}