const { EmbedBuilder } = require('discord.js');
const fetchBalance = require('../../functions/economy/fetchBalance');  // Correct the path if necessary

module.exports = {
    name: 'paraekle',
    description: 'Add money to a mentioned user',
    aliases: ['addmoney', 'addcoins'],
    async execute(client, message, args) {
        const requiredPermissions = ['MANAGE_ROLES'];

        const hasPermission = message.member.permissions.has(requiredPermissions);
        if (!hasPermission) {
            return message.reply('Bu komutu kullanma izniniz yok.');
        }

        const mentionedUser = message.mentions.users.first();
        const amount = parseInt(args[1], 10);

        if (!mentionedUser || isNaN(amount)) {
            return message.reply('Lütfen geçerli bir kullanıcı ve miktar belirtin.');
        }

        try {
            const storedBalance = await fetchBalance(mentionedUser.id, message.guild.id);
            storedBalance.balance += amount;
            await storedBalance.save();

            const embed = new EmbedBuilder()
                .setTitle(`${mentionedUser.username} adlı kullanıcının güncellenmiş bankası:`)
                .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setColor('#e1e1d5')
                .addFields({ name: 'Bakiye', value: `${storedBalance.balance} Galleon` })
                .setFooter({ text: client.user.tag, iconURL: client.user.displayAvatarURL({ dynamic: true }) });

            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error updating balance:', error);
            await message.reply('Bakiyeyi güncellerken bir hata oluştu.');
        }
    },
};
