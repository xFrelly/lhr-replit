const { EmbedBuilder } = require('discord.js');
const getBalance = require('../../functions/economy/getBalance');  // Correct the path if necessary

module.exports = {
    name: 'bakiye',
    description: 'Bakiyeyi gösterir',
    aliases: ['para', 'banka', 'cüzdan', 'cep', 'money', 'coins'],
    async execute(client, message, args) {
        const userId = message.author.id;
        const guildId = message.guild.id;

        try {
            const storedBalance = await getBalance(userId, guildId);

            if (!storedBalance || typeof storedBalance.balance === 'undefined') {
                console.error('Stored balance is invalid:', storedBalance);
                return await message.reply('Bakiyenizi gösterirken bir hata oluştu.');
            }

            const embed = new EmbedBuilder()
                .setTitle(`${message.author.username} adlı kullanıcının bankası:`)
                .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setColor('#e1e1d5')
                .addFields({ name: 'Bakiye', value: `${storedBalance.balance} Galleon` })
                .setFooter({ text: client.user.tag, iconURL: client.user.displayAvatarURL({ dynamic: true }) });

            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error fetching balance:', error);
            await message.reply('Bakiyenizi gösterirken bir hata oluştu.');
        }
    },
};
