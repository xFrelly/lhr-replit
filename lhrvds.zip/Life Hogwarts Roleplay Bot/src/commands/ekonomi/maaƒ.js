const { PermissionsBitField, SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fetchBalance = require('../../functions/economy/fetchBalance');

module.exports = {
    name: "maaş",
    data: new SlashCommandBuilder()
        .setName("maaş")
        .setDescription("Belirtilen role maaş verir.")
        .addRoleOption(option =>
            option.setName("rol")
                .setDescription("Maaş verilecek rol.")
                .setRequired(true)
        )
        .addNumberOption(option =>
            option.setName("miktar")
                .setDescription("Role verilecek maaş miktarı.")
                .setRequired(true)
        ),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply("Bu komutu kullanmak için gerekli yetki sadece @<1248726716004831385> rolünündür.");
        }

        const mentionedRole = interaction.options.getRole("rol");
        const amount = interaction.options.getNumber("miktar");
        const allMembers = await interaction.guild.members.fetch();
        const usersWithRole = allMembers.filter(member => member.roles.cache.has(mentionedRole.id));
        
        if (usersWithRole.size === 0) {
            return interaction.reply(`Belirtilen rolde üye bulunamadı.`);
        }

        await interaction.deferReply();

        for (const member of usersWithRole.values()) {
            try {
                let storedBalance = await fetchBalance(member.user.id, interaction.guild.id);
                storedBalance.balance += amount;
                await storedBalance.save();
            } catch (error) {
                console.error(`${member.user.id} bakiyesini yüklerken hata oluştu.`, error);
            }
        }

        await interaction.editReply(`${mentionedRole} rolüne sahip üyelere **${amount}** galleon yatırıldı.`);

        const embed = new EmbedBuilder()
            .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setDescription(`${mentionedRole} rolüne sahip üyelere <@${interaction.user.id}> tarafından **${amount}** galleon maaş yatırıldı.`)
            .setFooter({ text: "Life Hogwarts Roleplay - Maaş Sistemi", iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp();

        interaction.guild.channels.cache.get('1249467735021195375').send({ embeds: [embed] });
    }
};
