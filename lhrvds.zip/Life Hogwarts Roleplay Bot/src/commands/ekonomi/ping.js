module.exports = {
    name: "ping",
    description: "pong diye cevap verir",
    aliases: ["pingim"],
    async execute (message, args) {
        await message.reply("Pong!")
    },
};