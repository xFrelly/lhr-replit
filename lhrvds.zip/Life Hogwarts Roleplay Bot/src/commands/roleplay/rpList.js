const getRp = require("../../functions/roleplay/getRp");
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "rplist",
    description: "Sunucunun Roleplay puan sıralamasını gösterir.",
    aliases: ["rpliste", "rpsıralama", "rpsiralama", "rpls"],
    async execute(client, message, args) {
        try {
            // Fetch all members and their RP points
            let rpList = await Promise.all(message.guild.members.cache
                .filter(member => !member.user.bot)
                .map(async member => {
                    const points = await getRp(member.user.id, message.guild.id);
                    return { member, points: points || 0 }; // Ensure points is a number
                })
            );

            // Sort members by RP points in descending order
            rpList = rpList.sort((a, b) => b.points - a.points);

            // Create a list of the top 10 members or fewer if there are less than 10 members
            let list = '';
            const limit = Math.min(10, rpList.length);
            for (let i = 0; i < limit; i++) {
                if(typeof rpList[i].points.points === 'undefined') rpList[i].points.points === '0';
                list += `**${i + 1}**: <@${rpList[i].member.user.id}> | ${rpList[i].points.points} RP Puanı\n`;
            }

            if (!list) {
                list = 'Henüz yeterli sayıda roleplay puanı alan yok.';
            }

            const embed = new EmbedBuilder()
                .setTitle('Roleplay Puan Sıralaması')
                .setDescription(list)
                .setColor('#00FF00')
                .setFooter({ text: 'Güncel roleplay puan sıralaması', iconURL: message.guild.iconURL() });

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error generating RP list:', error);
            message.channel.send('Roleplay puan sıralamasını getirirken bir hata oluştu.');
        }
    },
};
