const { EmbedBuilder } = require('discord.js');
const getRp = require('../../functions/roleplay/getRp');  // Ensure this path is correct

module.exports = {
    name: 'rpPuanGoster',
    description: 'Kullanıcının RP puanlarını gösterir',
    aliases: ['rppuan', 'rp'],
    async execute(client, message, args) {
        const userId = message.author.id;
        const guildId = message.guild.id;

        try {
            const storedRp = await getRp(userId, guildId);

            if (!storedRp || typeof storedRp.points === 'undefined') {
                console.error('Stored rp points are invalid:', storedRp);
                return await message.reply('Henüz hiç Roleplay yapmamışsınız.');
            }

            const embed = new EmbedBuilder()
                .setTitle(`${message.author.username} adlı kullanıcının RP puanları:`)
                .setAuthor({ name: client.user.username, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setColor('#e1e1d5')
                .addFields({ name: 'RP Puanları', value: `${storedRp.points} puan` })
                .setFooter({ text: client.user.tag, iconURL: client.user.displayAvatarURL({ dynamic: true }) });

            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error fetching rp points:', error);
            await message.reply('RP puanlarınızı gösterirken bir hata oluştu.');
        }
    },
};
