const { EmbedBuilder } = require('discord.js');
const getBalance = require('../../functions/economy/getBalance');

module.exports = {
    name: "ecolist",
    description: "Zengin sıralaması yapar",
    aliases: ["zenginler"],
    async execute(client, message, args) {
        try {
            // Fetch all members and their balances
            let balanceList = await Promise.all(message.guild.members.cache
                .filter(member => !member.user.bot)
                .map(async member => {
                    const balanceData = await getBalance(member.user.id, message.guild.id);
                    return { member, balance: balanceData ? balanceData.balance : 0 }; // Ensure balance is a number
                })
            );

            // Sort members by balance in descending order
            balanceList = balanceList.sort((a, b) => b.balance - a.balance);

            // Create a list of the top 10 members or fewer if there are less than 10 members
            let listing = '';
            const limit = Math.min(10, balanceList.length);
            for (let i = 0; i < limit; i++) {
                listing += `**${i + 1}** - <@${balanceList[i].member.user.id}> | ${balanceList[i].balance.toLocaleString()} Galleon\n`;
            }

            if (!listing) {
                listing = 'Herkes Fakir.';
            }

            const embed = new EmbedBuilder()
                .setTitle('Life Hogwarts Roleplay Zenginlik Sıralaması')
                .setDescription(listing == "" ? "Kimsenin parası yok." : listing)
                .setColor('#00FF00')
                .setFooter({
                    text: 'Life Hogwarts Zenginleri',
                    iconURL: message.guild.iconURL({ dynamic: true })
                });

            message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error generating eco list:', error);
            message.reply('Zengin sıralamasını getirirken bir hata oluştu.');
        }
    }
};
