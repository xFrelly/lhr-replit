const { EmbedBuilder } = require('discord.js');
const getLevel = require('../../functions/leveling/getLevel');

module.exports = {
    name: 'level',
    description: 'Kullanıcının seviyesini gösterir',
    aliases: ['lvl', 'xp', "seviyem", "seviye", "svy"],
    async execute(client, message, args) {
        const userId = message.author.id;
        const guildId = message.guild.id;

        try {
            let storedLevel = await getLevel(userId, guildId);
            let requiredXp = 500 * Math.pow(3, storedLevel.level);

            if (!storedLevel || typeof storedLevel.level === 'undefined' || typeof storedLevel.xp === 'undefined') {
                console.error('Verilerdeki level veya xp sayısı geçersiz.', storedLevel);
                return await message.reply('Henüz hiç xp kazanmamışsınız.');
            }

            const embed = new EmbedBuilder()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
                .setColor('#e1e1d5')
                .setDescription(`Seviye - **${storedLevel.level.toLocaleString()}** | XP - **${storedLevel.xp.toFixed(1)}**/**${requiredXp.toFixed(1)}**`)
                .setFooter({ text: `LHR - Seviye Sistemi - Bilgi için !ylevel`, iconURL: message.guild.iconURL({ dynamic: true }) });
            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error fetching rp points:', error);
            await message.reply('Seviyenizi gösterirken bir hata oluştu.');
        }
    },
};
