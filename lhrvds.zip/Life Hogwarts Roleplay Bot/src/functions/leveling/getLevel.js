const level = require('../../schemas/level');

module.exports = async (userId, guildId) => {
    try {
        const storedLevel = await level.findOne({ userId, guildId });
        if (!storedLevel) {
            return false;
        }
        return storedLevel;
    } catch (error) {
        console.error('Error getting times:');
    }
};
