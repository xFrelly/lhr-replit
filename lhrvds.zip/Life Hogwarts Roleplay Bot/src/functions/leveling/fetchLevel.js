const { Types } = require('mongoose');  // Correct the path if necessary
const level = require('../../schemas/level');

module.exports = async (userId, guildId) => {
    try {
        let storedLevel = await level.findOne({ userId, guildId });

        if (!storedLevel) {
            storedLevel = new level({
                _id: new Types.ObjectId(),
                userId: userId,
                guildId: guildId,
                xp: 0, // Initialize xp to 0
                level: 0,  // Initialize level to 0
            });

            await storedLevel.save();
        }

        return storedLevel;
    } catch (error) {
        
    }
};
