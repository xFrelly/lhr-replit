const { Types } = require('mongoose');
const Times = require('../../schemas/timeDb');  // Correct the path if necessary

module.exports = async (userId, guildId) => {
    try {
        let storedTime = await Times.findOne({ userId, guildId });

        if (!storedTime) {
            storedTime = new Times({
                _id: new Types.ObjectId(),
                userId: userId,
                guildId: guildId,
                muteUntil: 0,  // Initialize muteUntil to 0
            });

            await storedTime.save();
        }

        return storedTime;
    } catch (error) {
        console.error('Error fetching times:');
    }
};
