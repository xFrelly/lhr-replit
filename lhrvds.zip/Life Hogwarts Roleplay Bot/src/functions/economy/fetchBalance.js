const { Types } = require('mongoose');
const Balance = require('../../schemas/balance');  // Correct the path if necessary

module.exports = async (userId, guildId) => {
    try {
        let storedBalance = await Balance.findOne({ userId, guildId });

        if (!storedBalance) {
            storedBalance = new Balance({
                _id: new Types.ObjectId(),
                userId: userId,
                guildId: guildId,
                balance: 0,  // Initialize balance to 0
            });

            await storedBalance.save();
        }

        return storedBalance;
    } catch (error) {
        console.error('Error fetching balance:');
    }
};
