const Balance = require('../../schemas/balance');  // Correct the path if necessary

module.exports = async (userId, guildId) => {
    try {
        console.log(`${userId} için bakiye değeri alınıyor.`)
        const storedBalance = await Balance.findOne({ userId, guildId });
        console.log(`Stored Balance: ${storedBalance}`)
        if (!storedBalance) {
            console.log(`${userId} için herhangi bir bakiye değeri bulamadım.`)
            return false;
        }
        return storedBalance;
    } catch (error) {
        console.error('Error getting balance:');
    }
};
