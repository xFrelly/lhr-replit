const Rp = require('../../schemas/rp');  // Ensure this path is correct

module.exports = async (userId, guildId) => {
    try {
        console.log(`Getting RP for user ${userId} in guild ${guildId}`);
        const storedRp = await Rp.findOne({ userId, guildId });
        console.log(`Stored RP: ${storedRp}`);
        if (!storedRp) {
            console.log(`${userId} ve ${guildId} için herhangi bir RP değeri bulamadım.`)
            return false;
        }
        return storedRp;
    } catch (error) {
        console.error('Error getting rp points:');
    }
};
