const { Types } = require('mongoose');
const Rp = require('../../schemas/rp');  // Ensure this path is correct

module.exports = async (userId, guildId) => {
    try {
        let storedRp = await Rp.findOne({ userId, guildId });

        if (!storedRp) {
            storedRp = new Rp({
                _id: new Types.ObjectId(),
                userId: userId,
                guildId: guildId,
                points: 0,  // Initialize rp points to 0
            });

            await storedRp.save();
        }

        return storedRp;
    } catch (error) {
        console.error('Error fetching rp:');
    }
};
