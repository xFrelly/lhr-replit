const { Client, GatewayIntentBits, ActivityType, Collection, EmbedBuilder, Events } = require('discord.js');
require('dotenv').config();
const { databaseToken } = process.env;
const { connect } = require('mongoose')
const fs = require('fs');
const { error } = require('console');
const categoryIDs = [
  '1248730332690386954', '1248731416288690206', '1248733028277293138',
  '1248733964307398747', '1248734257258434650', '1248928749437718529',
  '1248929048839585874', '1248929358178160702', '1248929682926075908',
  '1248929953316339833', '1248930807192752240', '1248931112919765074',
  '1248931430617059379', '1248931688642383933', '1248932056377856062',
  '1248933299624087624', '1248934009816223765', '1251481996459511880'
];
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers]
});
client.commands = new Collection();
client.commandArray = [];
const functionFolder = fs.readdirSync(`./src/functions/`);
for (const folder of functionFolder) {
  const functionFiles = fs
    .readdirSync(`./src/functions/${folder}`)
    .filter(file => file.endsWith('.js'));
  for (const files of functionFiles) {
    require(`./functions/${folder}/${files}`)(client);
  }

}

// Haftalık Roleplay Sistemi //

const fetchRp = require('../src/functions/roleplay/fetchRp');
const fetchLevel = require('../src/functions/leveling/fetchLevel')
client.on('messageCreate', async (message) => {


  if (!message.author || message.author.bot) return;

  if (categoryIDs.includes(message.channel.parentId)) {
    const wordCount = message.content.split(' ').length;
    try {
      let storedRp = await fetchRp(message.author.id, message.guild.id);
      let storedLevel = await fetchLevel(message.author.id, message.guild.id)

      if (!storedRp.channels.includes(message.channel.id)) {
        storedRp.channels.push(message.channel.id);
      }

      storedRp.lastChannel = message.channel.id;
      storedRp.points += wordCount;
      storedLevel.xp += wordCount * 0.1;
      let requiredXp = 500 * Math.pow(3, storedLevel.level);
      while (storedLevel.xp >= requiredXp) {
        storedLevel.xp -= requiredXp;
        storedLevel.level += 1;
        requiredXp = 500 * Math.pow(3, storedRp.level);

        message.author.send(`Tebrikler @<${message.author.id}>! Life Hogwarts Roleplay'de **${storedLevel.level}** seviyesine ulaştınız!\n
          *Ödülünüzü almak için <#1248726405819273238> kanalına !ödül yazarak ödülünüzü alabilirsiniz.*`)
      }
      await storedRp.save();
      await storedLevel.save()
      console.log(`Added ${wordCount} points and ${wordCount * 0.1} xp to user ${message.author.id} in guild ${message.guild.id}`);
    } catch (error) {
      console.error('Error updating rp points:', error);
    }
  }
})

client.on('messageDelete', async (message) => {

  if (!message.author || message.author.bot) return; // Ignore bot messages

  if (categoryIDs.includes(message.channel.parentId)) {
    const wordCount = message.content.split(' ').length;
    try {
      let storedRp = await fetchRp(message.author.id, message.guild.id);
      let storedLevel = await fetchLevel(message.author.id, message.guild.id)
      storedRp.points -= wordCount;
      // Update XP
      storedLevel.xp -= wordCount * 0.1;

      // Level down logic
      while (storedLevel.level > 1 && storedLevel.xp < 0) {
        storedLevel.level -= 1;
        storedLevel.xp += 500 * Math.pow(3, storedLevel.level);
      }
      if (storedLevel.xp < 0 && storedLevel.level < 0) {
        storedLevel.xp = 0;
        storedLevel.level = 0;
      }
      await storedRp.save();
      await storedLevel.save()
    } catch (error) {
      console.error('Error updating rp points:', error);
    }
  }
})

client.on(Events.GuildMemberAdd, async (member) => {
  const giveRole = member.guild.roles.cache.get("1248745536584945757");
  const log = member.guild.channels.cache.get('1248722864329195593');
  await member.roles.add(giveRole);
  const embed = new EmbedBuilder()
    .setTitle(`Sunucuya yeni bir kullanıcı katıldı.`)
    .setAuthor({ name: member.user.username, iconURL: member.user.displayAvatarURL({ dynamic: true }) })
    .addFields(
      {
        name: `Sunucuya katılma tarihi:`,
        value: member.joinedAt.toDateString()
      },
      {
        name: "Hesap oluşturulma tarihi:",
        value: member.user.createdAt.toDateString()
      }
    )
    .setFooter({ text: member.guild.name, iconURL: member.guild.iconURL({ dynamic: true }) })
    .setTimestamp();
  const embed2 = new EmbedBuilder()
    .setTitle(`Life Hogwarts Roleplay'e hoşgeldin!`)
    .setDescription(`<@${member.id}> Bu mektubu okuduğuna göre Hogwarts Cadılık ve Büyücülük okulunun mektubu eline ulaşmış demektir. Şimdi ise tek dileğimiz okul araç-gereçlerini toplayıp, 9¾ numaralı peron ile gelmen. Seni Hogwarts'ın Yeni  mirasının ve yeni neslinin bir parçası olarak kabul etmeyi sabırsızlıkla bekliyoruz..
Saygılarımla.
Profesör Parya Betsalel...

Bunların yanı sıra: Life Hogwarts Roleplay ekibinin, size daha kaliteli hizmet vermesi amacıyla bilmeniz gereken unsurlarımız bulunuyor; Size örnek vereceğimiz kayıt şablonunu kendi üzerinizden ayarlamanız gerekmektedir. Bu şablonu ⁠<#1248722157324861544>'na atmanız gerekmektedir. Örnek Şablonlar;

İsim/ Yaş/ Bina İsteği (Ravenclaw>Hufflepuff>Gryffindor>Slytherin)/ Kan durumu(Melez/Safkan/Bulanık)/ Cinsiyet(Kadın/Erkek)
•
Nur/ 19/ Bina Gryffindor>Slytherin>Hufflepuff>Ravenclaw>/  Kan Durumu - Safkan/ Cinsiyet - Kadın

Kayıt süreci içerisinde herhangi bir ses kanalına girip, ⁠🍁<#1248722157324861544> kanalına kayıt yetkilisi tagını kullanması gerekiyor.`)

  log.send({ embeds: [embed] });
  member.guild.channels.cache.get('1248722072641994832').send({ embeds: [embed2]})
});





client.handleEvents();
client.handleCommands();
client.login(process.env.TOKEN);
(async () => {
  await connect(databaseToken).catch(console.error)
})();