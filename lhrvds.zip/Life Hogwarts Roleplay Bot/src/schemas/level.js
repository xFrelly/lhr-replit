const { Schema, model, Types } = require('mongoose');

const levelSchema = new Schema({
    _id: { type: Types.ObjectId, auto: true },
    userId: String,
    guildId: String,
    xp: { type: Number, default: 0 },
    level: { type: Number , default: 0 }
});

module.exports = model('level', levelSchema , "levels");
